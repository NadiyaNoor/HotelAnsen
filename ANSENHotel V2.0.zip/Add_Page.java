import java.awt.EventQueue;

import javax.swing.JFrame;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import net.miginfocom.swing.MigLayout;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.awt.Font;
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Add_Page {

	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs = null;
	
	public class setVisible {

	}

	private JFrame frmAdd;
	private JTextField fName;
	private JTextField mName;
	private JTextField lName;
	private JTextField dateBirth;
	private JTextField phoneNum;
	private JTextField eMail;
	private JTextField numChildren;
	private JTextField checkIn;
	private JTextField checkOut;

	/**
	 * Launch the application.
	 */
	public static void newPage() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Page window = new Add_Page();
					window.frmAdd.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Add_Page() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public static boolean frame2check = false;
	public static boolean getFrame2Check(){
		return frame2check;
	}
	private void initialize() {
		frmAdd = new JFrame();
		frmAdd.setTitle("Add");
		frmAdd.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 15));
		frmAdd.setBounds(100, 100, 628, 418);
		frmAdd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAdd.getContentPane().setLayout(null);
		
		JLabel lblFillOfThe = new JLabel("Fill of the information");
		lblFillOfThe.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblFillOfThe.setBounds(235, 11, 147, 14);
		frmAdd.getContentPane().add(lblFillOfThe);
		
		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblFirstName.setBounds(10, 48, 100, 14);
		frmAdd.getContentPane().add(lblFirstName);
		
		fName = new JTextField();
		fName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		fName.setBounds(10, 73, 192, 32);
		frmAdd.getContentPane().add(fName);
		fName.setColumns(10);
		
		
		JLabel lblMiddle = new JLabel("Middle Name");
		lblMiddle.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMiddle.setBounds(212, 48, 100, 14);
		frmAdd.getContentPane().add(lblMiddle);
		
		mName = new JTextField();
		mName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		mName.setBounds(212, 73, 192, 32);
		frmAdd.getContentPane().add(mName);
		mName.setColumns(10);
		
		
		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblLastName.setBounds(414, 48, 106, 14);
		frmAdd.getContentPane().add(lblLastName);
		
		lName = new JTextField();
		lName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lName.setBounds(414, 73, 192, 32);
		frmAdd.getContentPane().add(lName);
		lName.setColumns(10);
		
		
		JLabel lblDob = new JLabel("DOB");
		lblDob.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDob.setBounds(10, 131, 46, 14);
		frmAdd.getContentPane().add(lblDob);
		
		dateBirth = new JTextField();
		dateBirth.setFont(new Font("Tahoma", Font.PLAIN, 15));
		dateBirth.setBounds(10, 156, 192, 32);
		frmAdd.getContentPane().add(dateBirth);
		dateBirth.setColumns(10);
		
		
		JLabel lblNewLabel = new JLabel("Phone");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(212, 131, 70, 14);
		frmAdd.getContentPane().add(lblNewLabel);
		
		phoneNum = new JTextField();
		phoneNum.setFont(new Font("Tahoma", Font.PLAIN, 15));
		phoneNum.setBounds(212, 156, 192, 32);
		frmAdd.getContentPane().add(phoneNum);
		phoneNum.setColumns(10);
		String name=phoneNum.getText();
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail.setBounds(414, 131, 46, 14);
		frmAdd.getContentPane().add(lblEmail);
		
		eMail = new JTextField();
		eMail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		eMail.setBounds(414, 156, 192, 32);
		frmAdd.getContentPane().add(eMail);
		eMail.setColumns(10);
		
		
		JLabel lblOfAdult = new JLabel("# of Adult");
		lblOfAdult.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblOfAdult.setBounds(10, 222, 100, 14);
		frmAdd.getContentPane().add(lblOfAdult);
		
		JComboBox numAdult = new JComboBox();
		numAdult.setFont(new Font("Tahoma", Font.PLAIN, 15));
		numAdult.setBounds(10, 247, 192, 32);
		frmAdd.getContentPane().add(numAdult);
		
		
		JLabel lblOfChildren = new JLabel("# of Children");
		lblOfChildren.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblOfChildren.setBounds(212, 222, 114, 14);
		frmAdd.getContentPane().add(lblOfChildren);
		
		numChildren = new JTextField();
		numChildren.setFont(new Font("Tahoma", Font.PLAIN, 15));
		numChildren.setBounds(212, 247, 192, 32);
		frmAdd.getContentPane().add(numChildren);
		numChildren.setColumns(10);
		
		
		JLabel lblCheckInout = new JLabel("Check in/out");
		lblCheckInout.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCheckInout.setBounds(10, 332, 100, 14);
		frmAdd.getContentPane().add(lblCheckInout);
		
		checkIn = new JTextField();
		checkIn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		checkIn.setBounds(120, 331, 126, 32);
		frmAdd.getContentPane().add(checkIn);
		checkIn.setColumns(10);
		
		
		checkOut = new JTextField();
		checkOut.setFont(new Font("Tahoma", Font.PLAIN, 15));
		checkOut.setBounds(256, 331, 126, 32);
		frmAdd.getContentPane().add(checkOut);
		checkOut.setColumns(10);
		
		
		JButton btnReset = new JButton("Reset");
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnReset.setBounds(500, 271, 89, 23);
		frmAdd.getContentPane().add(btnReset);
		
		JButton btnSave = new JButton("Save");
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String firstName=fName.getText();
				String lastName=lName.getText();
				String middleName= mName.getText();
				String dateOfBirth=dateBirth.getText();
				String phoneNumber = phoneNum.getText();
				String emailAdd = eMail.getText();
				String numOfAdult= (String)numAdult.getSelectedItem();
				String numOfChildren = numChildren.getText();
				String dateIN= checkIn.getText();
				String dateOUT= checkOut.getText();
				try{
					String sql ="INSERT INTO ANSENHotel(firstName, lastName, DOBirth, Phone, Email, "
							+ "numAdult, numChild, dateIN, dateOUT) "
							+ "VALUES (?,?,?,?,?,?,?,?,?)";
					String driver = "com.mysql.jdbc.Driver";
					String url = "jdbc:mysql://sql9.freesqldatabase.com:3306/sql9202621";
					String username = "sql9202621";
					String password = "BfdXwG8yyL";
					Class.forName(driver);

					con = DriverManager.getConnection(url,username,password);
					pst=con.prepareStatement(sql);
					pst.setString(1, firstName);
					pst.setString(2, lastName);
					pst.setString(3, dateOfBirth);
					pst.setString(4, phoneNumber);
					pst.setString(5, emailAdd);
					pst.setString(6, numOfChildren);
					pst.setString(7, numOfChildren);
					pst.setString(8, dateIN);
					pst.setString(9, dateOUT);
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Saved");
					
					
				}catch(Exception el){
					JOptionPane.showMessageDialog(null, el);
				}
			}
		});
		btnSave.setBounds(500, 305, 89, 23);
		frmAdd.getContentPane().add(btnSave);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmAdd.setVisible(false);
				frame2check = true;
			}
		});
		btnClose.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnClose.setBounds(500, 339, 89, 23);
		frmAdd.getContentPane().add(btnClose);
	}
	
	
}
