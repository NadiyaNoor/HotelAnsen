import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSeparator;
import java.awt.BorderLayout;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginPage {

	private JFrame loginPage;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage window = new LoginPage();
					window.loginPage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		loginPage = new JFrame();
		loginPage.setBounds(100, 100, 699, 478);
		loginPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loginPage.getContentPane().setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(310, 436, 0, -434);
		loginPage.getContentPane().add(separator);
		
		JPanel StaffPanel = new JPanel();
		StaffPanel.setBounds(323, 0, 360, 439);
		loginPage.getContentPane().add(StaffPanel);
		StaffPanel.setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField.setBounds(142, 115, 142, 20);
		StaffPanel.add(textField);
		textField.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUsername.setBounds(53, 116, 93, 14);
		StaffPanel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPassword.setBounds(53, 147, 93, 14);
		StaffPanel.add(lblPassword);
		
		
		JLabel lblNewLabel = new JLabel("Enter your info");
		lblNewLabel.setBounds(53, 226, 231, 14);
		StaffPanel.add(lblNewLabel);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_2.setBounds(142, 146, 142, 20);
		StaffPanel.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Add staff= new Add();
				String id="admin";
				String pw="password";
				if(textField.getText().equals(id)&&textField_2.getText().equals(pw)){
					staff.mainStaffPage();
					lblNewLabel.setText("Access Granted");
				}else if(!textField.getText().equals(id)&&textField_2.getText().equals(pw)){
					lblNewLabel.setText("Access Denied! Invalid usrname");
				}else if(textField.getText().equals(id)&&!textField_2.getText().equals(pw)){
					lblNewLabel.setText("Access Denied! Invalid password");
				}else{
					lblNewLabel.setText("Access Denied! Invalid usrname or password");
				}
			}
		});
		btnLogin.setBounds(195, 189, 89, 23);
		StaffPanel.add(btnLogin);
		
		StaffPanel.setVisible(false);
		
		JButton btnNewButton = new JButton("Staff");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StaffPanel.setVisible(true);
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(106, 132, 89, 39);
		loginPage.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Guest");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_1.setBounds(106, 237, 89, 39);
		loginPage.getContentPane().add(btnNewButton_1);
		
	}
}
