import java.awt.EventQueue;

import javax.swing.JFrame;

public class Modify_Page {

	private JFrame modifyPage;

	/**
	 * Launch the application.
	 */
	public static void modifyPage() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Modify_Page window = new Modify_Page();
					window.modifyPage.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Modify_Page() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		modifyPage = new JFrame();
		modifyPage.setBounds(100, 100, 826, 532);
		modifyPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
